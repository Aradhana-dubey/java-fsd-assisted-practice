package quickSort;

import java.util.Scanner;
import java.util.Arrays;

public class quickSortDemo {
	
	 public static void quickSort(int[] arr, int low, int high) {
	        if (low < high) {
	            int partitionIndex = partition(arr, low, high);

	            quickSort(arr, low, partitionIndex - 1);
	            quickSort(arr, partitionIndex + 1, high);
	        }
	    }

	    public static int partition(int[] array, int low, int high) {
	        int pivot = array[high];
	        int i = low - 1;

	        for (int j = low; j < high; j++) {
	            if (array[j] <= pivot) {
	                i++;

	              
	                int temp = array[i];
	                array[i] = array[j];
	                array[j] = temp;
	            }
	        }

	        int temp = array[i + 1];
	        array[i + 1] = array[high];
	        array[high] = temp;

	        return i + 1;
	    }
	

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		 
		 System.out.print("Enter the size of the  array: ");
	        int size = scanner.nextInt();

	        
	        int[] array = new int[size];
	        System.out.println("Enter the  elements of the array:");
	        for (int i = 0; i < size; i++) {
	            array[i] = scanner.nextInt();
	        }
		
		System.out.println("Original array: " + Arrays.toString(array));

        quickSort(array, 0, array.length - 1);

        System.out.println("Sorted array: " + Arrays.toString(array));
        scanner.close();

	}

}
