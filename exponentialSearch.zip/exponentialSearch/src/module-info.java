/**
 * 
 */
/**
 * 
 */
module exponentialSearch {
}