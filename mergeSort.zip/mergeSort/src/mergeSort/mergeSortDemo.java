package mergeSort;

import java.util.Arrays;
import java.util.Scanner;

public class mergeSortDemo {
	
	
	 public static void mergeSort(int[] arr, int left, int right) {
	        if (left < right) {
	            int mid = left + (right - left) / 2;

	            mergeSort(arr, left, mid);
	            mergeSort(arr, mid + 1, right);

	            merge(arr, left, mid, right);
	        }
	    }

	    public static void merge(int[] array, int left, int mid, int right) {
	        int n1 = mid - left + 1;
	        int n2 = right - mid;

	        int[] leftArr = new int[n1];
	        int[] rightArr = new int[n2];

	        System.arraycopy(array, left, leftArr, 0, n1);
	        System.arraycopy(array, mid + 1, rightArr, 0, n2);

	        int i = 0, j = 0, k = left;

	        while (i < n1 && j < n2) {
	            if (leftArr[i] <= rightArr[j]) {
	                array[k] = leftArr[i];
	                i++;
	            } else {
	                array[k] = rightArr[j];
	                j++;
	            }
	            k++;
	        }

	        while (i < n1) {
	            array[k] = leftArr[i];
	            i++;
	            k++;
	        }

	        while (j < n2) {
	            array[k] = rightArr[j];
	            j++;
	            k++;
	        }
	    }
	

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		 
		 System.out.print("Enter the size of the  array: ");
	        int size = scanner.nextInt();

	        
	        int[] array = new int[size];
	        System.out.println("Enter the  elements of the array:");
	        for (int i = 0; i < size; i++) {
	            array[i] = scanner.nextInt();
	        }
		
		
		 System.out.println("Original array: " + Arrays.toString(array));

	        mergeSort(array, 0, array.length - 1);

	        System.out.println("Sorted array: " + Arrays.toString(array));
	        
	        scanner.close();
	}

}
