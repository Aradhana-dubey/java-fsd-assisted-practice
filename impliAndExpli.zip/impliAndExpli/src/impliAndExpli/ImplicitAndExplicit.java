package impliAndExpli;

public class ImplicitAndExplicit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int x=7;
       double y=x;
       System.out.println("Implicit Typecasting:" +y);
       
       double d=7.5;
       int e=(int)d;
       System.out.println("Explicit Typecasting:" +e);
	}

}
